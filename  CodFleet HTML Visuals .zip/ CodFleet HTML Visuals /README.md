# CodFleet
CodFleet Website Hosting and Development
⚡ Perfect — let’s create two essentials for CodFleet:
	1.	README.md → for any developer who opens this repo/files.
	2.	Wireframe + Site Map (textual flow map) → so anyone (designer/dev/investor) instantly understands the navigation and connections.

⸻

📄 CodFleet README.md (Developer Guide)

# CodFleet – Compliance-First Workforce Platform

CodFleet is a **compliance-first freelancer marketplace** that connects companies, freelancers, and education partners in Finland.  
This repository contains **UI/UX screens, flows, and legal-safe components** for CodFleet’s WebApp + Mobile App.

---

## 📌 Tech Stack
- **Frontend**: Next.js (React), TailwindCSS, Glassmorphic UI theme
- **Backend**: Node.js + Express (planned), Firebase for auth/logs (MVP)
- **Database**: Firestore (MVP), later Postgres
- **Integrations**: PSP Escrow, Vero.fi APIs, YEL/Insurance verifications
- **AI Helpers**: Gemini/Stitch for UI export, Kaizen AI (compliance), Lumen AI (matching)

---

## 🎨 Design System
- **Font**: Roboto Mono
- **Colors**:
  - Dark Navy `#0D1B2A` (background)
  - White `#FFFFFF` (primary text)
  - Accent Cyan `#00E5FF` (links, actives)
  - Accent Green `#00C896` (CTA, verified states)
  - Amber `#FFB703` (warnings, expiry alerts)
  - Red `#FF4D4D` (errors, cancelled)
- **Theme**: Glassmorphic, Nordic minimalism

---

## 🛡 Legal Rules (MUST FOLLOW)
- CodFleet is **NOT an employer** or staffing provider.
- Always refer to **freelancers as independent businesses**.
- Use words: *task, opportunity, invoicing, escrow, compliance*.
- Avoid: *hire, employee, wage, shift, dispatch*.
- All invoices must state: *“Freelancers invoice clients directly via CodFleet. CodFleet provides compliance verification & invoicing; it does not employ or lease labour.”*

---

## 🔗 Core Modules
- **Public Website**: Marketing site (Home, Story, Network, Insights, Contact, Investors, Legal, FAQ, System Status)
- **Freelancer Console (Mobile-first)**: Dashboard, Tasks, Compliance Vault, Earnings, Upskilling
- **Company Console (Web-first)**: Task Board + Map, Compliance Hub, Talent Pool, Invoices & Payments
- **Education Console**: Course Management, Certifications, Partnerships
- **Admin Console**: Super Admin controls, KYC/KYB, Compliance Monitor, Fraud Detection, Analytics
- **Support Console**: Tickets, Chat, FAQ/Macros CMS
- **Finance Console**: Escrow Ledger, Payouts, Reports
- **Government Console (Read-only)**: KPIs, Compliance packs, Transparency exports

---

## 🚦 Contribution Workflow
1. **Branching**: `feature/<name>`, `fix/<name>`
2. **Commit Style**: Conventional Commits (feat:, fix:, docs:)
3. **Code Style**: Prettier + ESLint
4. **Testing**: Jest + Cypress (UI flows)
5. **Deployment**: Vercel (Web), Expo (Mobile)

---

## 📂 File Structure

/public-site       → Marketing pages
/freelancer-app    → Freelancer console (mobile-first)
/company-console   → Company dashboard (web)
/edu-console       → Education partners
/admin-console     → Super Admin + Compliance Ops
/support-console   → Tickets, chat, FAQ
/finance-console   → Escrow, payouts, tax
/gov-console       → Read-only compliance portal
/shared            → Components (buttons, forms, nav)
/legal             → ToS, Privacy, Cookie, Imprint

---

## 🧭 Quick Start
```bash
npm install
npm run dev

Visit: http://localhost:3000

⸻

📞 Contact
	•	Founder & CEO: Yash Panchal
	•	Compliance Lead AI: Kaizen
	•	Matching AI: Lumen
	•	Email: support@codfleet.com

---

# 🗺 CodFleet Wireframe / Site Map

### 🌍 Public Website
- **Home** → Hero → “Join” CTA → Footer  
- **The CodFleet Story** → Vision, Mission, Timeline, Team  
- **Network (Join)** → Choose Role: Freelancer / Company / Education  
  - Freelancer → Registration → Onboarding → Dashboard  
  - Company → Registration → Org Setup → Dashboard  
  - Education → Registration → Dashboard  
- **Insights & Updates** → Blog + News  
- **Investors** → Overview + Access Request + NDA  
- **Contact** → Form + HQ Map + Support  
- **Legal** → ToS, Privacy, Cookie, Imprint  
- **FAQ** → Top Q&A (Payment, Compliance, Taxes, Role)  
- **System Status** → Uptime, Incidents, Maintenance  

---

### 📱 Freelancer Console (Mobile-first)
1. Login → Dashboard  
2. Profile → Edit data  
3. Compliance Vault → Upload docs, expiry alerts  
4. Task Board → Apply → In-progress → Proof & Submit → Earnings  
5. Upskilling Hub → Courses → Certificates Wallet  
6. Earnings Overview → Payouts & History  
7. Support → FAQ → Ticket/Chat  
8. Settings → Preferences → Privacy → Close Account  

---

### 💻 Company Console (Web-first)
1. Dashboard (Overview)  
2. Task Board + Map View → Task Details → Reassign/Cancel  
3. Compliance Hub → Upload/View compliance pack  
4. Talent Pool (browse verified freelancers)  
5. Invoices & Payments → Escrow & Approvals  
6. Contracts Hub → NDA, MSA, DPA  
7. Reports → Ops & Spend analytics  
8. Settings → Team & Roles → Billing → Data & Privacy  

---

### 🎓 Education Console
1. Dashboard  
2. Course Management → Create / Bulk Upload  
3. Certifications → Issue / Verify / Bulk  
4. Partnership Settings → SLA, Billing, Data & Privacy  

---

### 🛡 Admin Console
1. Super Admin Home  
2. User Registry  
3. KYC/KYB Queue  
4. Compliance Monitor  
5. Fraud Detection  
6. Task Oversight  
7. Integrations (Wolt/Posti connectors)  
8. Authority Requests (Gov)  
9. GDPR DSAR / Erasure  
10. Content CMS  
11. Analytics Board View  
12. Audit Trail  

---

### 🎧 Support Console
1. Dashboard → Queue, SLA  
2. Ticket Management → Assign, Notes  
3. Chat/Comms → Live Support  
4. FAQ/Macros CMS  

---

### 📊 Finance Console
1. Dashboard → Cashflow, AR/AP, Payouts Queue  
2. Escrow Ledger → Trust accounting  
3. Payouts → SEPA export  
4. Fees & Tax Settings  
5. Reports → Monthly/Quarterly  

---

### 🏛 Government Console
1. Gov Dashboard → KPIs, Compliance %  
2. Data Requests → Packs by entity/date  
3. Compliance Reports → Monthly/Quarterly  
4. Analytics → Macro workforce trends  

---

👉 This way, any **developer or designer** opening the repo knows:  
- What CodFleet is.  
- How files and modules connect.  
- Navigation flow from **Public site → Consoles → Admin/Gov**.  

---

Do you want me to **turn this wireframe map into a visual flow diagram** (arrows + boxes) so it’s easier for non-tech readers too?